class Klass(object):
    """A"""
    __doc__ += "B"
