# -*- coding: IBO-8859-1 -*-
""" check correct unknown encoding declaration
"""

__revision__ = '����'

