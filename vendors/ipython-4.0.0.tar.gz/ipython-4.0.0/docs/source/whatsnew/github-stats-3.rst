.. _issues_list_3:

Issues closed in the 3.x development cycle
==========================================

Issues closed in 3.1
--------------------

GitHub stats for 2015/02/27 - 2015/04/03 (since 3.0)

These lists are automatically generated, and may be incomplete or contain duplicates.

We closed 46 issues and merged 133 pull requests.
The full list can be seen `on GitHub <https://github.com/ipython/ipython/milestones/3.1>`__.

The following 33 authors contributed 344 commits:

* Abe Guerra
* Adal Chiriliuc
* Benjamin Ragan-Kelley
* Brian Drawert
* Fernando Perez
* Gareth Elston
* Gert-Ludwig Ingold
* Giuseppe Venturini
* Jakob Gager
* Jan Schulz
* Jason Grout
* Jessica B. Hamrick
* Jonathan Frederic
* Justin Tyberg
* Lorena Pantano
* mashenjun
* Mathieu
* Matthias Bussonnier
* Morten Enemark Lund
* Naveen Nathan
* Nicholas Bollweg
* onesandzeroes
* Patrick Snape
* Peter Parente
* RickWinter
* Robert Smith
* Ryan Nelson
* Scott Sanderson
* Sylvain Corlay
* Thomas Kluyver
* tmtabor
* Wieland Hoffmann
* Yuval Langer


Issues closed in 3.0
--------------------

GitHub stats for 2014/04/02 - 2015/02/13 (since 2.0)

These lists are automatically generated, and may be incomplete or contain duplicates.

We closed 469 issues and merged 925 pull requests.
The full list can be seen `on GitHub <https://github.com/ipython/ipython/milestones/3.0>`__.

The following 155 authors contributed 5975 commits.

* A.J. Holyoake
* abalkin
* Adam Hodgen
* Adrian Price-Whelan
* Amin Bandali
* Andreas Amann
* Andrew Dawes
* Andrew Jesaitis
* Andrew Payne
* AnneTheAgile
* Aron Ahmadia
* Ben Duffield
* Benjamin ABEL
* Benjamin Ragan-Kelley
* Benjamin Schultz
* Björn Grüning
* Björn Linse
* Blake Griffith
* Boris Egorov
* Brian E. Granger
* bsvh
* Carlos Cordoba
* Cedric GESTES
* cel
* chebee7i
* Christoph Gohlke
* CJ Carey
* Cyrille Rossant
* Dale Jung
* Damián Avila
* Damon Allen
* Daniel B. Vasquez
* Daniel Rocco
* Daniel Wehner
* Dav Clark
* David Hirschfeld
* David Neto
* dexterdev
* Dimitry Kloper
* dongweiming
* Doug Blank
* drevicko
* Dustin Rodriguez
* Eric Firing
* Eric Galloway
* Erik M. Bray
* Erik Tollerud
* Ezequiel (Zac) Panepucci
* Fernando Perez
* foogunlana
* Francisco de la Peña
* George Titsworth
* Gordon Ball
* gporras
* Grzegorz Rożniecki
* Helen ST
* immerrr
* Ingolf Becker
* Jakob Gager
* James Goppert
* James Porter
* Jan Schulz
* Jason Goad
* Jason Gors
* Jason Grout
* Jason Newton
* jdavidheiser
* Jean-Christophe Jaskula
* Jeff Hemmelgarn
* Jeffrey Bush
* Jeroen Demeyer
* Jessica B. Hamrick
* Jessica Frazelle
* jhemmelg
* Jim Garrison
* Joel Nothman
* Johannes Feist
* John Stowers
* John Zwinck
* jonasc
* Jonathan Frederic
* Juergen Hasch
* Julia Evans
* Justyna Ilczuk
* Jörg Dietrich
* K.-Michael Aye
* Kalibri
* Kester Tong
* Kyle Kelley
* Kyle Rawlins
* Lev Abalkin
* Manuel Riel
* Martin Bergtholdt
* Martin Spacek
* Mateusz Paprocki
* Mathieu
* Matthias Bussonnier
* Maximilian Albert
* mbyt
* MechCoder
* Mohan Raj Rajamanickam
* mvr
* Narahari
* Nathan Goldbaum
* Nathan Heijermans
* Nathaniel J. Smith
* ncornette
* Nicholas Bollweg
* Nick White
* Nikolay Koldunov
* Nile Geisinger
* Olga Botvinnik
* Osada Paranaliyanage
* Pankaj Pandey
* Pascal Bugnion
* patricktokeeffe
* Paul Ivanov
* Peter Odding
* Peter Parente
* Peter Würtz
* Phil Elson
* Phillip Nordwall
* Pierre Gerold
* Pierre Haessig
* Raffaele De Feo
* Ramiro Gómez
* Reggie Pierce
* Remi Rampin
* Renaud Richardet
* Richard Everson
* Scott Sanderson
* Silvia Vinyes
* Simon Guillot
* Spencer Nelson
* Stefan Zimmermann
* Steve Chan
* Steven Anton
* Steven Silvester
* sunny
* Susan Tan
* Sylvain Corlay
* Tarun Gaba
* Thomas Ballinger
* Thomas Kluyver
* Thomas Robitaille
* Thomas Spura
* Tobias Oberstein
* Torsten Bittner
* unknown
* v923z
* vaibhavsagar
* W. Trevor King
* weichm
* Xiuming Chen
* Yaroslav Halchenko
* zah
