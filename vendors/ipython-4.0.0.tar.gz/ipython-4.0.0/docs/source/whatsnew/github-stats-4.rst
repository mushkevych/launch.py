.. _issues_list_4:

Issues closed in the 4.x development cycle
==========================================

Issues closed in 4.0
--------------------


GitHub stats for 2015/02/27 - 2015/08/11 (since 3.0)

These lists are automatically generated, and may be incomplete or contain duplicates.

We closed 35 issues and merged 125 pull requests.
The full list can be seen `on GitHub <https://github.com/ipython/ipython/milestone/4.0>`__

The following 69 authors contributed 1186 commits.

* Abe Guerra
* Adal Chiriliuc
* Alexander Belopolsky
* Andrew Murray
* Antonio Russo
* Benjamin Ragan-Kelley
* Björn Linse
* Brian Drawert
* chebee7i
* Daniel Rocco
* Donny Winston
* Drekin
* Erik Hvatum
* Fernando Perez
* Francisco de la Peña
* Frazer McLean
* Gareth Elston
* Gert-Ludwig Ingold
* Giuseppe Venturini
* Ian Barfield
* Ivan Pozdeev
* Jakob Gager
* Jan Schulz
* Jason Grout
* Jeff Hussmann
* Jessica B. Hamrick
* Joe Borg
* Joel Nothman
* Johan Forsberg
* Jonathan Frederic
* Justin Tyberg
* Koen van Besien
* Kyle Kelley
* Lorena Pantano
* Lucretiel
* Marin Gilles
* mashenjun
* Mathieu
* Matthias Bussonnier
* Merlijn van Deen
* Mikhail Korobov
* Naveen Nathan
* Nicholas Bollweg
* nottaanibot
* Omer Katz
* onesandzeroes
* Patrick Snape
* patter001
* Peter Parente
* Pietro Battiston
* RickWinter
* Robert Smith
* Ryan Nelson
* Scott Sanderson
* Sebastiaan Mathot
* Sylvain Corlay
* thethomask
* Thomas A Caswell
* Thomas Adriaan Hellinger
* Thomas Kluyver
* Tianhui Michael Li
* tmtabor
* unknown
* Victor Ramirez
* Volker Braun
* Wieland Hoffmann
* Yuval Langer
* Zoltán Vörös
* Élie Michel
