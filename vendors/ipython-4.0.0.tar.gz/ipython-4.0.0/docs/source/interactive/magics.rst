=======================
Built-in magic commands
=======================

.. include:: magics-generated.txt
