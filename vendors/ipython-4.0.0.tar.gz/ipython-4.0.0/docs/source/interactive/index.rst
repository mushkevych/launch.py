==================================
Using IPython for interactive work
==================================

.. toctree::
   :maxdepth: 2

   tutorial
   magics
   plotting
   qtconsole
   reference
   shell
   tips

.. seealso::

    `The Jupyter Notebook <http://jupyter-notebook.readthedocs.org/en/latest/>`__
