.. _install_index:

============
Installation
============

.. toctree::
   :maxdepth: 2

   install
   kernel_install

